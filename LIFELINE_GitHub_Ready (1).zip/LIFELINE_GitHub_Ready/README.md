# LIFELINE – Emergency Vehicle Green Corridor Simulation

A Flask-based web simulation for an emergency vehicle green corridor.

## Features
- Start screen for the LIFELINE application
- Emergency vehicle selection (ambulance, fire engine, police)
- Traffic density selection
- Browser GPS location detection
- Destination search using Photon geocoding
- Driving route display using OSRM and Leaflet
- Route distance and estimated travel time display
- Three simulated traffic signals that change as the vehicle marker approaches
- Animated emergency vehicle marker

## Project structure
```text
LIFELINE/
├── app.py
├── requirements.txt
├── README.md
└── templates/
    └── index.html
```

## Run locally
1. Install Python 3.
2. Open a terminal in this folder.
3. (Optional) Create and activate a virtual environment.
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Start the Flask app:
   ```bash
   python app.py
   ```
6. Open http://127.0.0.1:5000 in your browser.

## Notes
- Internet access is needed for the OpenStreetMap map tiles, Photon geocoding, and OSRM routing services.
- GPS access generally requires localhost or a secure HTTPS connection and browser permission.
- This is an academic simulation, not a real traffic-control system. It does not control physical traffic lights or provide an official emergency response service.
- Do not commit passwords, API keys, `.env` files, virtual environments, or personal data.
